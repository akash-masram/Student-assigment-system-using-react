import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './LoginPage.css';
import TeacherDashboard from './TeacherDashboard';
import StudentDashboard from './StudentDashboard';
import AdminDashboard from '../admin/AdminDashboard';

const LoginPage = ({ onLogin, userRole }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [selectedRole, setSelectedRole] = useState('');
  const [userData, setUserData] = useState(null); // State to hold user data
  const navigate = useNavigate();

  const handleLogin = async () => {
    if (username && password && selectedRole) {
      try {
        let endpoint = '';
        let requestBody = {};

        // Construct endpoint and request body based on selected role
        if (selectedRole === 'teacher') {
          endpoint = 'http://127.0.0.1:8070/api/v1/teacher/teacher/login';
          requestBody = {
            teacherEmail: username,
            teacherPassword: password,
          };
        } else if (selectedRole === 'student') {
          endpoint = 'http://127.0.0.1:8070/api/v1/student/student/login';
          requestBody = {
            studentPRN: username,
            studentPassword: password,
          };
        } else if (selectedRole === 'admin') {
          endpoint = 'http://127.0.0.1:8070/api/v1/main/admin/login';
          requestBody = {
            adminEmail: username,
            adminPassword: password,
          };
        } else {
          console.error('Invalid role selected');
          return;
        }

        const response = await fetch(endpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(requestBody),
        });

        if (response.ok) {
          const data = await response.json();
          setUserData(data); // Store user data
          onLogin(selectedRole, data); // Assuming you have a function to handle successful login
          navigate(`/${selectedRole}`);
          console.log(data);
          const jsonData = JSON.stringify(data);
          localStorage.setItem('teacherData', jsonData);
          console.log('Data stored successfully in local storage.');
        } else {
          const errorMessage = await response.text();
          console.error('Login failed:', errorMessage);
        }
      } catch (error) {
        console.error('Error during login:', error);
      }
    }
  };

  if (userRole === 'teacher' && userData) {
    // Render TeacherDashboard component if userRole is 'teacher' and userData is available
    return (
      <TeacherDashboard
        onLogout={() => {
          localStorage.removeItem('teacherData');
          console.log('Data cleared from local storage.');
        } }
        teacherName={userData.teacherName}
        teacherBranch={userData.teacherBranch}
      />
    );
  } else if (userRole === 'student' && userData) {
    // Render StudentDashboard component if userRole is 'student' and userData is available
    return (
      <StudentDashboard
        onLogout={() => {
          localStorage.removeItem('teacherData');
          console.log('Data cleared from local storage.')
        } /* Implement logout logic here */}
        studentName={userData.studentName}
        studentPRN={userData.studentPRN}
        studentBranch={userData.studentBranch}
      />
    );
  } else if (userRole === 'admin' && userData) {
    // Render AdminDashboard component if userRole is 'admin' and userData is available
    return (
      <AdminDashboard
        onLogout={() => {
          
        } /* Implement logout logic here */}
        adminName={userData.adminName}
        adminRole={userData.adminRole}
      />
    );
  }

  // Render login form
  return (
    <div className="container">
      <div className="form-container">
        <h2 className="fw-bold mb-2 text-uppercase">Assignment Managment System</h2>
        <h3>Login</h3>

        <label className="input-label">Username:</label>
        <input
          type="text"
          className="input-field"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          placeholder="Enter your username"
        />

        <label className="input-label">Password:</label>
        <input
          type="password"
          className="input-field"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Enter your password"
        />

        <div className="role-buttons">
          <button
            className={`role-button ${selectedRole === 'student' ? 'active' : ''}`}
            onClick={() => setSelectedRole('student')}
          >
            Student
          </button>
          <button
            className={`role-button ${selectedRole === 'teacher' ? 'active' : ''}`}
            onClick={() => setSelectedRole('teacher')}
          >
            Teacher
          </button>
          <button
            className={`role-button ${selectedRole === 'admin' ? 'active' : ''}`}
            onClick={() => setSelectedRole('admin')}
          >
            Admin
          </button>
        </div>

        <div className="d-grid">
        <button className ="login-button" variant="primary" onClick={handleLogin}>
          Login
        </button>
        </div>
        
        

      </div>
    </div>
  );
};

export default LoginPage;
