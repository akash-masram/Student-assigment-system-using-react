import React, { useState } from 'react';
import './TeacherDashboard.css';

const TeacherDashboard = ({ onLogout }) => {
  const [files, setFiles] = useState([]);
  const [qrCodeData, setQrCodeData] = useState(null);
  const [title, setTitle] = useState('');
  const [uploading, setUploading] = useState(false);

  const handleFileChange = (event) => {
    const newFiles = Array.from(event.target.files);
    setFiles((prevFiles) => [...prevFiles, ...newFiles]);
  };

  const handleTitleChange = (event) => {
    setTitle(event.target.value);
  };

  const removeFile = (index) => {
    setFiles((prevFiles) => prevFiles.filter((_, i) => i !== index));
  };

  const data = JSON.parse(localStorage.getItem('teacherData'));

  const handleFormSubmit = async (event) => {
    event.preventDefault();

    if (files.length === 0) {
      alert('Please select at least one file.');
      return;
    }

    try {
      const formData = new FormData();
      for (let i = 0; i < files.length; i++) {
        formData.append('file', files[i]);
      }
      formData.append('title', title);

      setUploading(true);

      const response = await fetch('http://127.0.0.1:8070/api/v1/teacher/upload', {
        method: 'POST',
        body: formData,
      });

      if (response.ok) {
        const qrCodeBlob = await response.blob();
        const qrCodeDataURL = URL.createObjectURL(qrCodeBlob);
        setQrCodeData(qrCodeDataURL);
        alert('QR generated successfully.');
      } else {
        if (response.status === 409) {
          const errorData = await response.text();
          alert(errorData);
        } else {
          const errorData = await response.json();
          alert('Error: ' + errorData.message);
        }
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Network error occurred. Please try again later.');
    } finally {
      setUploading(false);
    }
  };

  const handleDownloadQRCode = () => {
    if (!qrCodeData) {
      alert('Please upload a document to generate the QR code first.');
      return;
    }

    if (!title) {
      alert('Please enter a title before downloading.');
      return;
    }

    const filename = `${title.toLowerCase().replace(/\s+/g, '-')}-qrcode.png`;

    const link = document.createElement('a');
    link.href = qrCodeData;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="teacher-dashboard-container">
      <div className="header">
        <div className="welcome-message">
          <h2 className="fw-bold mb-2 text-uppercase">Assignment Management System</h2>
        </div>

        <div className="teacher-info">
          <p>{`Teacher: ${data.teacherName}`}</p>
          <p>{`Branch: ${data.teacherBranch}`}</p>
          <button
            onClick={() => {
              localStorage.removeItem('teacherData');
              onLogout();
            }}
            className="logout-button"
          >
            Logout
          </button>
        </div>
      </div>

      <div className="upload-section">
        <label className="label">Upload Document:</label>
        <form onSubmit={handleFormSubmit}>
          <div className="file-input">
            <input type="file" onChange={handleFileChange} multiple />
            <button type="button" onClick={() => document.getElementById('additional-file-input').click()}>
              Add More Files
            </button>
            <input
              id="additional-file-input"
              type="file"
              style={{ display: 'none' }}
              onChange={handleFileChange}
              multiple
            />
          </div>
          <br />
          {files.length > 0 && (
            <div className="selected-files">
              <p>Selected Files:</p>
              <ul>
                {files.map((file, index) => (
                  <li key={index}>
                    {file.name}
                    <button type="button" onClick={() => removeFile(index)}>Remove</button>
                  </li>
                ))}
              </ul>
            </div>
          )}
          <br />
          <p>Enter title for your QR code : </p>
          <input type="text" placeholder="Enter title for QR code" value={title} onChange={handleTitleChange} />
          {uploading ? (
            <button type="submit" className="upload-button" disabled>Uploading...</button>
          ) : (
            <button type="submit" className="upload-button">Generate QR</button>
          )}
        </form>
      </div>

      {qrCodeData && (
        <div className="generated-qr-code">
          <h3>QR Code</h3>
          <img src={qrCodeData} alt="QR Code" />
          <p>{title}</p>
        </div>
      )}

      <button onClick={handleDownloadQRCode} className="download-button">
        Download QR Code
      </button>
    </div>
  );
};

export default TeacherDashboard;
