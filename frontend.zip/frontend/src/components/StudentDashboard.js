import React, { useState } from 'react';
import './StudentDashboard.css';
import QRScanner from './QRScanner';

const StudentDashboard = ({ onLogout }) => {
  const [scannerKey, setScannerKey] = useState(0); // State to force re-render of QRScanner

  const handleScanAgain = () => {
    // Increment the key to force re-render of QRScanner
    setScannerKey(prevKey => prevKey + 1);
  };

  return (
    <div className="dashboard-container">
      <h2 className="fw-bold mb-2 text-uppercase">Assignment Management System</h2>
      <div className="scan-again-container">
        <QRScanner key={scannerKey} /> {/* Pass the scannerKey as a prop */}
        <button onClick={handleScanAgain} className="scan-again-button">Scan Again</button> {/* Add Scan Again button */}
      </div>
      <button onClick={onLogout} className="logout-button">Logout</button>
    </div>
  );
};

export default StudentDashboard;
