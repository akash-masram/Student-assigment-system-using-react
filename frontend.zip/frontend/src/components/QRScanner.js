import React, { useState, useEffect } from 'react';
import { QrReader } from 'react-qr-reader';
import axios from 'axios';
import './QRScanner.css';

const QRScanner = ({ key }) => {
  const [result, setResult] = useState('');
  const [scanned, setScanned] = useState(false);
  const [error, setError] = useState(null);
  const [files, setFiles] = useState([]);

  const handleScan = async (data) => {
    try {
      if (data) {
        setResult(data);
        setScanned(true);
        fetchData(data);
      }
    } catch (err) {
      setError(err);
      setScanned(true);
    }
  };

  const handleError = (err) => {
    setError(err);
    setScanned(true);
  };

  const fetchData = async (uuid) => {
    try {
      const response = await axios.get(`http://127.0.0.1:8070/api/v1/student/assignments?uuid=${uuid}`);
      if (response.data.length > 0) {
        setFiles(response.data);
      }
    } catch (err) {
      setError(err);
    }
  };

  const downloadFile = async (uuid, fileName) => {
    try {
      const response = await axios.get(`http://127.0.0.1:8070/api/v1/student/download/${uuid}/${fileName}`, {
        responseType: 'blob',
      });
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', fileName);
      document.body.appendChild(link);
      link.click();
      link.parentNode.removeChild(link);
    } catch (err) {
      setError(err);
    }
  };

  useEffect(() => {
    if (result) {
      fetchData(result);
    }
  }, [result]);

  return (
    <>
      {!scanned && (
        <div>
          <br />
          <br />
          <h5>To Access Assignment scan your QR code below</h5>
          <QrReader
            delay={300}
            onError={handleError}
            onScan={handleScan}
            onResult={handleScan}
            style={{ width: '70%' }}
            key={key}
          />
        </div>
      )}
      {scanned && (
        <>
          {files.length > 0 ? (
            <div>
              <p>Files:</p>
              <ul>
                {files.map((file, index) => (
                  <li key={index}>
                    <div className='download-list'>
                      <div className='file-name'>{file.fileName}</div>
                      <button className="download-btn custom-green-btn" onClick={() => downloadFile(result, file.fileName)}>Download</button>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          ) : (
            <p>No files found</p>
          )}
        </>
      )}
      {error && <p>Error: {error.message}</p>}
    </>
  );
};

export default QRScanner;
