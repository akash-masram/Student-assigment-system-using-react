// admin/AdminRoutes.js
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import TeacherDashboard from '../admin/Teacher';
import StudentDashboard from '../admin/student';
import Admin from '../admin/home'

const AdminRoutes = () => {
  return (
    <Routes>
      <Route path="home" element={<Admin />} />
      <Route path="teacher" element={<TeacherDashboard />} />
      <Route path="student" element={<StudentDashboard />} />
    </Routes>
  );
};

export default AdminRoutes;
