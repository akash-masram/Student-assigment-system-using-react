import React, { useState } from 'react';
import axios from 'axios';
import './Teacher.css'; // Import CSS file for styling

const Teacher = () => {
  const [teacherData, setTeacherData] = useState({
    teacherName: '',
    teacherEmail: '',
    teacherPassword: '',
    teacherBranch: '', // Change this to hold the selected branch
    teacherSubject: ''
  });
  const [successMessage, setSuccessMessage] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setTeacherData({ ...teacherData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://127.0.0.1:8070/api/v1/main/teacher/registerTeacher', teacherData);
      setSuccessMessage(response.data); // Assuming response is "Teacher registered successfully"
      // Clear form fields after successful registration
      setTeacherData({
        teacherName: '',
        teacherEmail: '',
        teacherPassword: '',
        teacherBranch: '',
        teacherSubject: ''
      });
    } catch (error) {
      console.error('Error registering teacher:', error);
      // Handle error - show an error message to the user
    }
  };

  return (
    <div className="teacher-form-container">
      <h2>Register Teacher</h2>
      {successMessage && <p className="success-message">{successMessage}</p>}
      <form onSubmit={handleSubmit} className="teacher-form">
        <label>
          Name:
        </label>
        <input type="text" name="teacherName" value={teacherData.teacherName} onChange={handleChange} />
        <br />
        <label>
          Email:
        </label>
        <input type="email" name="teacherEmail" value={teacherData.teacherEmail} onChange={handleChange} />
        <br />
        <label>
          Password:
        </label>
        <input type="password" name="teacherPassword" value={teacherData.teacherPassword} onChange={handleChange} />
        <br />
        <label>
          Select Branch :
        </label>
        <select name="teacherBranch" value={teacherData.teacherBranch} onChange={handleChange}>
          <option value="">Select Branch</option>
          <option value="CSE">CSE</option>
          <option value="IT">IT</option>
          <option value="Mechanical">Mechanical</option>
          <option value="Civil">Civil</option>
          <option value="Electrical">Electrical</option>
          <option value="Electronics">Electronics</option>
        </select>
        <br />
        <label>
          Subject:
        </label>
        <input type="text" name="teacherSubject" value={teacherData.teacherSubject} onChange={handleChange} />
        <br />
        <button type="submit" className="submit-button">Register Teacher</button>
      </form>
    </div>
  );
};

export default Teacher;
