import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import AdminRoutes from './AdminRoutes';
import { Container, Nav, Navbar } from 'react-bootstrap';
import './AdminDashboard.css';
import Button from 'react-bootstrap/Button';

const AdminDashboard = ({ onLogout }) => {
  const location = useLocation();

  return (
    <Container>
      <Navbar bg="light" expand="lg">
        <Navbar.Brand as={Link} to="/admin/home">Admin Dashboard</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="mr-auto">
            <CustomNavLink to="/admin/home" currentPath={location.pathname}>
              Home
            </CustomNavLink>
            <CustomNavLink to="/admin/teacher" currentPath={location.pathname}>
              Teachers
            </CustomNavLink>
            <CustomNavLink to="/admin/student" currentPath={location.pathname}>
              Students
            </CustomNavLink>
          </Nav>
          <Button onClick={onLogout} variant="danger" className="bg-btn">Log out </Button>{''}
        </Navbar.Collapse>
      </Navbar>
      <AdminRoutes />
    </Container>
  );
};

// Custom NavLink component to handle active state
const CustomNavLink = ({ to, currentPath, children }) => {
  const isActive = currentPath === to;
  return (
    <Nav.Link as={Link} to={to} className={isActive ? 'active' : ''}>
      {children}
    </Nav.Link>
  );
};

export default AdminDashboard;
