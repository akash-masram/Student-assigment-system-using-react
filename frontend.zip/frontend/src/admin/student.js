import React, { useState } from 'react';
import axios from 'axios';
import './Student.css'; // Import CSS file for styling

const Student = () => {
  const [studentData, setStudentData] = useState({
    studentPRN: '',
    studentName: '',
    studentEmail: '',
    studentPassword: '',
    studentBranch: '', // Change this to hold the selected branch
    studentYear: ''
  });
  const [successMessage, setSuccessMessage] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setStudentData({ ...studentData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://127.0.0.1:8070/api/v1/main/student/registerStudent', studentData);
      setSuccessMessage(response.data); // Assuming response is "Student registered successfully"
      // Clear form fields after successful registration
      setStudentData({
        studentPRN: '',
        studentName: '',
        studentEmail: '',
        studentPassword: '',
        studentBranch: '',
        studentYear: ''
      });
    } catch (error) {
      console.error('Error registering student:', error);
      // Handle error - show an error message to the user
    }
  };

  return (
    <div className="student-form-container">
      <h2>Register Student</h2>
      {successMessage && <p className="success-message">{successMessage}</p>}
      <form onSubmit={handleSubmit} className="student-form">
        <label>
          PRN:
        </label>
        <input type="text" name="studentPRN" value={studentData.studentPRN} onChange={handleChange} />
        <br />
        <label>
          Name:
        </label>
        <input type="text" name="studentName" value={studentData.studentName} onChange={handleChange} />
        <br />
        <label>
          Email:
        </label>
        <input type="email" name="studentEmail" value={studentData.studentEmail} onChange={handleChange} />
        <br />
        <label>
          Password:
        </label>
        <input type="password" name="studentPassword" value={studentData.studentPassword} onChange={handleChange} />
        <br />
        <label>
          Select Branch : 
        </label>
        <select name="studentBranch" value={studentData.studentBranch} onChange={handleChange}>
          <option value="">Select Branch</option>
          <option value="cse">CSE</option>
          <option value="it">IT</option>
          <option value="mech">Mechanical</option>
          <option value="civil">Civil</option>
          <option value="ee">Electrical</option>
          <option value="eln">Electronics</option>
        </select>
        <br />
        <label>
          Year:
        </label>
        <input type="text" name="studentYear" value={studentData.studentYear} onChange={handleChange} />
        <br />
        <button type="submit" className="submit-button">Register Student</button>
      </form>
    </div>
  );
};

export default Student;
