import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Admin.css'; // Import CSS file for styling

const Home = () => {
  const [students, setStudents] = useState([]);
  const [teachers, setTeachers] = useState([]);
  const [studentBranch, setStudentBranch] = useState('cse');
  const [teacherBranch, setTeacherBranch] = useState('cse');

  useEffect(() => {
    const fetchStudents = async () => {
      try {
        const response = await axios.get(`http://127.0.0.1:8070/api/v1/main/students?branch=${studentBranch}`);
        setStudents(response.data);
      } catch (error) {
        console.error('Error fetching student data:', error);
      }
    };

    const fetchTeachers = async () => {
      try {
        const response = await axios.get(`http://127.0.0.1:8070/api/v1/main/teachers?branch=${teacherBranch}`);
        setTeachers(response.data);
      } catch (error) {
        console.error('Error fetching teacher data:', error);
      }
    };

    fetchStudents();
    fetchTeachers();
  }, [studentBranch, teacherBranch]); // Fetch data whenever branch changes

  const handleStudentBranchChange = (event) => {
    setStudentBranch(event.target.value);
  };

  const handleTeacherBranchChange = (event) => {
    setTeacherBranch(event.target.value);
  };

  return (
    <div className="admin-form-container">
      <div className="column">
        <h2>Teacher </h2>
        <p>Select Branch :
        <select value={teacherBranch} onChange={handleTeacherBranchChange}>
        <option value="cse">CSE</option>
          <option value="it">IT</option>
          <option value="mech">Mechanical</option>
          <option value="civil">Civil</option>
          <option value="ee">Electrical</option>
          <option value="eln">Electronics</option>
          {/* Add more options as needed */}
        </select>
        </p>
        <table>
          <thead>
            <tr>
              <th>Name</th>
            </tr>
          </thead>
          <tbody>
            {teachers.map((teacher, index) => (
              <tr key={index}>
                <td>{teacher.name}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="column">
        <h2>Student </h2>

        <p>Select Branch : <select value={studentBranch} onChange={handleStudentBranchChange}>
          <option value="cse">CSE</option>
          <option value="it">IT</option>
          <option value="mech">Mechanical</option>
          <option value="civil">Civil</option>
          <option value="ee">Electrical</option>
          <option value="eln">Electronics</option>
          {/* Add more options as needed */}
          
        </select>
        </p>
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>PRN</th>
            </tr>
          </thead>
          <tbody>
            {students.map((student, index) => (
              <tr key={index}>
                <td>{student.name}</td>
                <td>{student.PRN}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Home;
